package com.examplecodes.learnapplication.ProgramFragments;

import com.examplecodes.learnapplication.DataModel;

public interface InterfazActivityFragment {


    public void LadderData(DataModel InformacionEscalera);
    public void AndamioData(DataModel InformacionAndamio);
    public void AlturaData(DataModel InfoAltura);

}
