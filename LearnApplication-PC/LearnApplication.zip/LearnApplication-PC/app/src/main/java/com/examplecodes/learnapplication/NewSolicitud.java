package com.examplecodes.learnapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.examplecodes.learnapplication.Funciones.DataBase;
import com.examplecodes.learnapplication.ProgramFragments.FragmentAndamios;
import com.examplecodes.learnapplication.ProgramFragments.FragmentEscaleras;
import com.examplecodes.learnapplication.ProgramFragments.InterfazActivityFragment;
import com.examplecodes.learnapplication.ProgramFragments.PagerControler;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.examplecodes.learnapplication.R.*;

public class NewSolicitud extends AppCompatActivity implements InterfazActivityFragment, View.OnClickListener {

    DataBase dataBase;
    ViewPager TabsViewPager;
    TabLayout TabsEquipos;
    TabItem TabEscalera, TabAndamio, TabEqAltura;
    Button ContinuarSolicitud;
    EditText FechaInitSolicitud, FechaEndSolicitud;

    Date FechaEnd;
    Date FechaInit;
    Date Today;
    private int diaInit, mesInit, añoInit, diaEnd, mesEnd, añoEnd;

    DataModel dataLadderModel, dataAndamioModel, dataEQAlturaModel;
    PagerControler pagerAdapter;
    private Intent IntentToProgEscalera2;

    boolean EscaleraSolicitada = false, AndamioSolicitado = false, EPCCSolicitado = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.new_solicitud);

        dataLadderModel = ViewModelProviders.of(this).get(DataModel.class);
        dataAndamioModel = ViewModelProviders.of(this).get(DataModel.class);
        dataEQAlturaModel = ViewModelProviders.of(this).get(DataModel.class);

        TabsEquipos = (TabLayout) findViewById(id.EquiposTabLayout);
        TabsViewPager = (ViewPager) findViewById(id.TabsViewPager);
        TabEscalera = (TabItem) findViewById(id.TabEscalera);
        TabAndamio = (TabItem) findViewById(id.TabAndamio);
        TabEqAltura = (TabItem) findViewById(id.TabEQAltura);
        ContinuarSolicitud = (Button) findViewById(id.ButtContinuarSolicitud);

        FechaInitSolicitud = (EditText) findViewById(id.FechaInitSolicitud1);
        FechaInitSolicitud.setOnClickListener(this);

        FechaEndSolicitud = (EditText) findViewById(id.FechaEndSolicitud2);
        FechaEndSolicitud.setOnClickListener(this);


        pagerAdapter = new PagerControler(getSupportFragmentManager(), TabsEquipos.getTabCount());
        TabsViewPager.setAdapter(pagerAdapter);


        TabsEquipos.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                TabsViewPager.setCurrentItem(tab.getPosition());
                if (tab.getPosition() == 0) {
                    pagerAdapter.notifyDataSetChanged();
                }
                if (tab.getPosition() == 1) {
                    pagerAdapter.notifyDataSetChanged();
                }
                if (tab.getPosition() == 2) {
                    pagerAdapter.notifyDataSetChanged();
                }
                if (tab.getPosition() == 3) {
                    pagerAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        TabsViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(TabsEquipos));

        IntentToProgEscalera2 = new Intent(getApplicationContext(), ProgramEscaleraSecond.class);
    }

    @Override
    protected void onResume() {
        super.onResume();

        ContinuarSolicitud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CreateNewIntent();

                if (EscaleraSolicitada || AndamioSolicitado || EPCCSolicitado) {
                    startActivity(IntentToProgEscalera2);
                }else Toast.makeText(getApplicationContext(),"Aún no has solicitado un servicio", Toast.LENGTH_SHORT).show();

            }
        });


    }

    private void ProgramarServicio(){

    }

    @Override
    public void LadderData(DataModel InformacionEscalera) {
        dataLadderModel = InformacionEscalera;
        EscaleraSolicitada = dataLadderModel.Solicitud;
        IntentToProgEscalera2.putExtra("ServicioEscalera",EscaleraSolicitada); // Si se realizo la solicitud de una escalera
        //Toast.makeText(getApplicationContext(),"Solicitud Escalera: "+EscaleraSolicitada,Toast.LENGTH_SHORT).show();

        if (EscaleraSolicitada){

            // 3. Se crea el Intent para cambio de actividad
            IntentToProgEscalera2.putExtra("TipoEscalera", dataLadderModel.LadderType); // Tipo de escalera
            IntentToProgEscalera2.putExtra("IsRefEscalera", dataLadderModel.LadderReference); // Si se escogió una referencia
            IntentToProgEscalera2.putExtra("NumReferenceEscalera", dataLadderModel.NumLadderReference); // Numero de la referencia
            IntentToProgEscalera2.putExtra("PasosEscalera", dataLadderModel.LadderSteps); // Numero de pasos de la escalera que se escogió
            IntentToProgEscalera2.putExtra("FIEscalera", dataLadderModel.DILadder); // Fecha de inicio de la solicitud
            IntentToProgEscalera2.putExtra("FEEscalera", dataLadderModel.DELadder); // Fecha de Finalización de la solicitud
            IntentToProgEscalera2.putExtra("TotalDiasEscalera", dataLadderModel.LadderTotalDays); // Total de dias solicitados

        }


        /*Toast.makeText(getApplicationContext(), "Escalera " + dataLadderModel.LadderType + " " + dataLadderModel.LadderSteps + " Pasos # " +
                dataLadderModel.NumLadderReference + "; entre el " + dataLadderModel.DILadder + " y el " + dataLadderModel.DELadder, Toast.LENGTH_LONG).show(); */
    }

    @Override
    public void AndamioData(DataModel InformacionAndamio) {
        dataAndamioModel = InformacionAndamio;
        AndamioSolicitado = dataAndamioModel.Solicitud;
        IntentToProgEscalera2.putExtra("ServicioAndamio",AndamioSolicitado); // Si se realizo la solicitud de una escalera
        //Toast.makeText(getApplicationContext(),"Solicitud Andamio: "+AndamioSolicitado,Toast.LENGTH_SHORT).show();

        if (AndamioSolicitado){

            // 3. Se crea el Intent para cambio de actividad
            IntentToProgEscalera2.putExtra("TipoAndamio", dataAndamioModel.AndamioType); // Tipo de escalera
            IntentToProgEscalera2.putExtra("IsRefAndamio", dataAndamioModel.AndamReference); // Si se escogió una referencia
            IntentToProgEscalera2.putExtra("NumReferenceAndamio", dataAndamioModel.NumAndamReference); // Numero de la referencia
            IntentToProgEscalera2.putExtra("Secciones", dataAndamioModel.Secciones); // Numero de pasos de la escalera que se escogió
            IntentToProgEscalera2.putExtra("FIAndamio", dataAndamioModel.DIAndamio); // Fecha de inicio de la solicitud
            IntentToProgEscalera2.putExtra("FEAndamio", dataAndamioModel.DEAndamio); // Fecha de Finalización de la solicitud
            IntentToProgEscalera2.putExtra("TotalDiasAndamio", dataAndamioModel.AndamTotalDays); // Total de dias solicitados

        }


        /*
        if (dataAndamioModel.AndamioType.equals("Unipersonal")){

            Toast.makeText(getApplicationContext(), "Andamio " + dataAndamioModel.AndamioType + " #" +
                    dataAndamioModel.NumAndamReference + "; entre el " + dataAndamioModel.DIAndamio + " y el " + dataAndamioModel.DEAndamio, Toast.LENGTH_LONG).show();

        } else if (dataAndamioModel.AndamioType.equals("Certificado")){
            Toast.makeText(getApplicationContext(), "Andamio " + dataAndamioModel.AndamioType + " " + dataAndamioModel.Secciones + " Secciones;"
                    + " entre el " + dataAndamioModel.DIAndamio + " y el " + dataAndamioModel.DEAndamio, Toast.LENGTH_LONG).show();
        }
        */
    }

    @Override
    public void AlturaData(DataModel InfoAltura) {
        dataEQAlturaModel = InfoAltura;
        EPCCSolicitado = dataEQAlturaModel.Solicitud;
        IntentToProgEscalera2.putExtra("ServicioEPCC",EPCCSolicitado); // Si se realizo la solicitud de una escalera
        //Toast.makeText(getApplicationContext(),"Solicitud HSE/EPCC: "+ EPCCSolicitado,Toast.LENGTH_SHORT).show();

        if (EPCCSolicitado){

            // 3. Se crea el Intent para cambio de actividad
            IntentToProgEscalera2.putExtra("HSE",dataEQAlturaModel.HSE); // Si se realizo la solicitud de una escalera
            IntentToProgEscalera2.putExtra("HorarioHSE",dataEQAlturaModel.HorarioHSE); // Si se realizo la solicitud de una escalera
            IntentToProgEscalera2.putExtra("EQDescenso", dataEQAlturaModel.EQ_Descenso); // Tipo de escalera
            IntentToProgEscalera2.putExtra("Cuerda", dataEQAlturaModel.Cuerda); // Si se escogió una referencia
            IntentToProgEscalera2.putExtra("Señalizacion", dataEQAlturaModel.NumAndamReference); // Numero de la referencia
            IntentToProgEscalera2.putExtra("AlturaMax", dataEQAlturaModel.Secciones); // Numero de pasos de la escalera que se escogió
            IntentToProgEscalera2.putExtra("FIEPCC", dataEQAlturaModel.DIAndamio); // Fecha de inicio de la solicitud
            IntentToProgEscalera2.putExtra("FEEPCC", dataEQAlturaModel.DEAndamio); // Fecha de Finalización de la solicitud
            IntentToProgEscalera2.putExtra("TotalDiasEPCC", dataEQAlturaModel.EPCCTotalDias); // Total de dias solicitados
            IntentToProgEscalera2.putExtra("TotalEPCC", dataEQAlturaModel.TotalEQAltura); // Total de dias solicitados
            IntentToProgEscalera2.putExtra("BAGS", dataEQAlturaModel.Bags); // Total de dias solicitados


        }

        /*Toast.makeText(getApplicationContext(), "HSE: " + dataEQAlturaModel.HSE + " Horario HSE: " + dataEQAlturaModel.HorarioHSE + " MALETAS: " + dataEQAlturaModel.TotalEQAltura +
                " Maletas: " + dataEQAlturaModel.Bags[0] + "," + dataEQAlturaModel.Bags[1] + "," + dataEQAlturaModel.Bags[2] + "," + dataEQAlturaModel.Bags[3] +
                " EQ.Ascenso: " + dataEQAlturaModel.EQ_Descenso + " Señalización: " + dataEQAlturaModel.Señalizacion, Toast.LENGTH_LONG).show();
*/

    }


    private boolean DataComprovation(){
        return ((!FechaInitSolicitud.getText().toString().isEmpty())
                && (!FechaEndSolicitud.getText().toString().isEmpty())
                && (!FechaEnd.before(FechaInit)) && (!FechaInit.before(Today)));
    }

    private void ShowErrors(){
        if (!(FechaInitSolicitud.getText().toString().trim().isEmpty()) && !(FechaEndSolicitud.getText().toString().trim().isEmpty()) &&
                ((FechaEnd.before(FechaInit)) || (FechaInit.before(Today))))
            Toast.makeText(getApplicationContext(), "Verifica que las Fechas sean coherentes", Toast.LENGTH_LONG).show();
        if (FechaInitSolicitud.getText().toString().trim().isEmpty())
            FechaInitSolicitud.setError("Elige la fecha");
        if (FechaEndSolicitud.getText().toString().trim().equalsIgnoreCase(""))
            FechaEndSolicitud.setError("Elige la fecha");
        //Toast.makeText(getApplicationContext(), "Verifica que todos los campos esten Correctamente diligenciados", Toast.LENGTH_LONG).show();
    }

    private void ConvertirFechas() {

        // 1. Tomamos el valor de las Fechas y les convertimos a un fomato, para luego poderlas comparar
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // se crea el Formato al que se traduciran las fechas para luego compararlas
            Calendar c = Calendar.getInstance();
            String today = (c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH) + "");
            Today = sdf.parse(today);

            FechaInit = sdf.parse(FechaInitSolicitud.getText() + "");
            FechaEnd = sdf.parse(FechaEndSolicitud.getText() + "");

        } catch (ParseException e) {
            Toast.makeText(getApplicationContext(), "Ingresa todos los datos antes de consultar", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onClick(View v) {


        switch (v.getId()) {

            case R.id.FechaInitSolicitud1:
                Calendar cal = Calendar.getInstance();

                diaInit = cal.get(Calendar.DAY_OF_MONTH);
                mesInit = cal.get(Calendar.MONTH);
                añoInit = cal.get(Calendar.YEAR);

                DatePickerDialog datePickerDialogInit = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        FechaInitSolicitud.setText(year + "-" + (month + 1) + "-" + dayOfMonth);

                    }
                }
                        , añoInit, mesInit, diaInit);
                datePickerDialogInit.show();
                break;

            case R.id.FechaEndSolicitud2:
                Calendar cal2 = Calendar.getInstance();
                diaEnd = cal2.get(Calendar.DAY_OF_MONTH);
                mesEnd = cal2.get(Calendar.MONTH);
                añoEnd = cal2.get(Calendar.YEAR);

                DatePickerDialog datePickerDialogEnd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        FechaEndSolicitud.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                    }
                }
                        , añoEnd, mesEnd, diaEnd);
                datePickerDialogEnd.show();
                break;


        }

    }


}
