package com.examplecodes.learnapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ProgramEscaleraSecond extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {


    Chip Chip1, Chip2, Chip3, Chip4;
    ChipGroup chipGroup;
    String NombreProg, TelProg, EmailProg, AreaProg;
    AutoCompleteTextView NombreRecibe;
    EditText TelRecibe, EmailRecibe, AreaRecive;
    EditText HoraEntrega, Observaciones;
    EditText OTM, ClienteName, Nit, ClienteAddress;
    Button ConfSolicitud, ToHome, SearchInfo;
    ProgressBar ProgramProgressBar;

    RequestQueue requestQueue, requestQueueToProg;

    int hora, minuto;
    String NumEscToProgram, MyURL;
    static final String Tag = "DATO";

    boolean ProgServiceSuccess = false, ProgramInProcess = false;
    boolean ConsultaInProccess = false;
    final boolean Inicio = true;
    final boolean Finalizado = false;

    Intent IntentToHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.program_escalera_second);
        Log.d(Tag, "OnCreate");


        // Instanciamos los Objetos de la Interfaz
        Chip1 = (Chip) findViewById(R.id.chip_1);
        Chip2 = (Chip) findViewById(R.id.chip_2);
        Chip3 = (Chip) findViewById(R.id.chip_3);
        Chip4 = (Chip) findViewById(R.id.chip_4);
        chipGroup = (ChipGroup) findViewById(R.id.ChipGroup);

        NombreRecibe = (AutoCompleteTextView) findViewById(R.id.NombreQuienRecibe);
        TelRecibe = (EditText) findViewById(R.id.TelQuienRecibe);
        EmailRecibe = (EditText) findViewById(R.id.EmailQuienRecibe);
        AreaRecive = (EditText) findViewById(R.id.DepartamentoRecibe);

        OTM = (EditText) findViewById(R.id.OT_MPS);
        ClienteName = (EditText) findViewById(R.id.NameCliente);
        Nit = (EditText) findViewById(R.id.NitCliente);
        ClienteAddress = (EditText) findViewById(R.id.Direccion);
        HoraEntrega = (EditText) findViewById(R.id.HoraEntrega);
        HoraEntrega.setOnClickListener(this);

        Observaciones = (EditText) findViewById(R.id.Observaciones);
        ProgramProgressBar = (ProgressBar) findViewById(R.id.ProgramProgressBar);
        SearchInfo = (Button) findViewById(R.id.SearchPersonBoutton);
        ConfSolicitud = (Button) findViewById(R.id.ConfSolicitud);
        ToHome = (Button) findViewById(R.id.ButtHome);

        // Instanciamos las Listas Desplegables
        // Arrays de Autollenado
        ArrayAdapter<CharSequence> Nombres = ArrayAdapter.createFromResource(this, R.array.NamesList,android.R.layout.simple_dropdown_item_1line);
        NombreRecibe.setAdapter(Nombres);


        // Creamos la URL del servicio
        MyURL = "http://onkaix-com.preview-domain.com/DBConsDispEscalera.php?TipoEscalera=" + getIntent().getStringExtra("tipo") +
                "&Pasos=" + getIntent().getStringExtra("pasos") + "&Numero=0&FechaInit=" + getIntent().getStringExtra("fechaInit") +
                "&FechaEnd=" + getIntent().getStringExtra("fechaEnd");

        LoadPreference();

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(Tag, "OnRESUME");

        ToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentToHome = new Intent(ProgramEscaleraSecond.this, MainMenuActivity.class);
                startActivity(IntentToHome);
            }
        });

        ConfSolicitud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Si no se ha programado el servicio de manera Exitosa
                if(ProgramInProcess == false && ProgServiceSuccess == false) {

                    IndicadoresDeProceso(Inicio, "ProgService");

                    // validamos que toda la información Esté diligenciada
                    if (DataValidation()) {

                        ConfirmarDiponibilidad(MyURL);

                    }else {
                        IndicadoresDeProceso(Finalizado, "ProgService");
                    }

                }else {
                    if (ProgServiceSuccess == true)
                        Toast.makeText(getApplicationContext(), "Su solicitud ya fué procesada", Toast.LENGTH_LONG).show();
                    if (ProgramInProcess == true)
                        Toast.makeText(getApplicationContext(), "Solicitud en proceso...", Toast.LENGTH_LONG).show();
                }
            }
        });

        SearchInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IndicadoresDeProceso(Inicio,"ConsInfo");
                ConsultaPersonal("http://onkaix-com.preview-domain.com/DBConsultaInfoPersonal.php?");
            }
        });


    }

    private void IndicadoresDeProceso(boolean state, String from){

        switch (from){
            case "ProgService":
                        if (state == Finalizado){
                            ProgServiceSuccess = false;
                            ProgramInProcess = false;
                            ProgramProgressBar.setVisibility(View.INVISIBLE);
                            NombreRecibe.setEnabled(true);
                            TelRecibe.setEnabled(true);
                            AreaRecive.setEnabled(true);
                            EmailRecibe.setEnabled(true);

                            OTM.setEnabled(true);
                            ClienteName.setEnabled(true);
                            Nit.setEnabled(true);
                            ClienteAddress.setEnabled(true);
                            HoraEntrega.setEnabled(true);

                        }

                        if (state == Inicio){
                            ProgServiceSuccess = false;
                            ProgramInProcess = true;
                            ProgramProgressBar.setVisibility(View.VISIBLE);
                            NombreRecibe.setEnabled(false);
                            TelRecibe.setEnabled(false);
                            AreaRecive.setEnabled(false);
                            EmailRecibe.setEnabled(false);

                            OTM.setEnabled(false);
                            ClienteName.setEnabled(false);
                            Nit.setEnabled(false);
                            ClienteAddress.setEnabled(false);
                            HoraEntrega.setEnabled(false);

                        }
                        break;

            case "ConsInfo":
                        if (state == Finalizado){
                            ConsultaInProccess = false;
                            NombreRecibe.setEnabled(true);
                            TelRecibe.setEnabled(false);
                            AreaRecive.setEnabled(false);
                            EmailRecibe.setEnabled(false);
                        }

                        if (state == Inicio){
                            ConsultaInProccess = true;
                            NombreRecibe.setEnabled(false);
                            TelRecibe.setEnabled(false);
                            AreaRecive.setEnabled(false);
                            EmailRecibe.setEnabled(false);
                        }
                        break;
        }

    }

    // Ejecuta una consulta en la Base de Datos
    private void ConsultaPersonal(String URL){

        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    //Se transforma el String response en un JSONArray
                    JSONArray Respuesta = new JSONArray(response);
                    JSONObject RecibeInfo;
                    //Luego se extrae el primer objeto del array
                    RecibeInfo = Respuesta.getJSONObject(0);

                    Toast.makeText(getApplicationContext(), "Info Loaded Successfull", Toast.LENGTH_SHORT).show();

                    if (RecibeInfo.getString("INFO_RESPONSE").equals("SUCCESS")){

                        TelRecibe.setEnabled(true);
                        AreaRecive.setEnabled(true);
                        EmailRecibe.setEnabled(true);

                        TelRecibe.setText(RecibeInfo.getString("CELULAR1"));
                        EmailRecibe.setText(RecibeInfo.getString("CORREO"));
                        AreaRecive.setText(RecibeInfo.getString("AREA"));

                        IndicadoresDeProceso(Finalizado,"ConsInfo");

                    }else if (RecibeInfo.getString("INFO_RESPONSE").equals("NOTSUCCESS")){
                        IndicadoresDeProceso(Finalizado,"ConsInfo");
                        Toast.makeText(getApplicationContext(), "Fallo la Solicitud. Intente nuevamente " +response, Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    IndicadoresDeProceso(Finalizado,"ConsInfo");
                    Toast.makeText(getApplicationContext(), "Bad Conexion: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(),"Error ProgEscSecond - EjecProgram BadConexión: " + error.toString(),Toast.LENGTH_LONG).show();
                IndicadoresDeProceso(Finalizado, "ProgService");
            }
        }){

            // Mapa de toda la Información con la que se solicitará el servicio. <-- IMPORTANTE
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>parametros = new HashMap<String, String>();
                //parametros.put("ESTADO_SERVICIO", "PROGRAMADO");
                parametros.put("NAME",NombreRecibe.getText().toString());

                return parametros;
            }
        };
        requestQueueToProg= Volley.newRequestQueue(this);
        requestQueueToProg.add(stringRequest);




    }


    // Ejecuta una consulta en la Base de Datos
    private void ConfirmarDiponibilidad(String URL){

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {

                JSONObject InfoPersonal = null;

                try {

                    InfoPersonal = response.getJSONObject(0);                     // Escogemos el primer Objeto JSON
                    NumEscToProgram = (InfoPersonal.getString("NumeroEscalera")); // Escogemos el valor con la CLAVE "NumeroEscalera"

                    if (NumEscToProgram.equals("NoExist")){
                        Toast.makeText(getApplicationContext(), "Esta escalera NO EXISTE en el Inventario", Toast.LENGTH_SHORT).show();
                        IndicadoresDeProceso(Finalizado,"ProgService");
                    }else if(NumEscToProgram.equals("0")){
                        Toast.makeText(getApplicationContext(), "Esta escalera YA NO SE ENCUENTRA DISPONIBLE. Vuelve a consultar", Toast.LENGTH_SHORT).show();
                        IndicadoresDeProceso(Finalizado,"ProgService");
                    }else if (!NumEscToProgram.equals("0")){
                        Toast.makeText(getApplicationContext(), "Escalera disponible: #" + NumEscToProgram, Toast.LENGTH_SHORT).show();
                        GenerarSolicitud("http://onkaix-com.preview-domain.com/DBProgramService.php", NumEscToProgram);
                    }

                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Error ProgEscSecond - EjecServicio Jarray: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    IndicadoresDeProceso(Finalizado,"ProgService");
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error ProgEscSecond - EjecServicio Bad Conexión: " + error.getMessage(), Toast.LENGTH_LONG ).show();
                IndicadoresDeProceso(Finalizado,"ProgService");
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);


    }

    // Crea un servicio en la Base de Datos
    private void GenerarSolicitud(String URL, final String NEscalera){

                StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    int i = response.indexOf("_");
                    String ProgramResponse = response.substring(0,i);
                    if (ProgramResponse.equals("SUCCESS")){
                        IndicadoresDeProceso(Finalizado,"ProgService");
                        ProgServiceSuccess = true;
                        Toast.makeText(getApplicationContext(), "Solicitud creada con éxito : )", Toast.LENGTH_LONG).show();
                        IntentToHome = new Intent(ProgramEscaleraSecond.this,MainMenuActivity.class);
                        startActivity(IntentToHome);
                    }else if (ProgramResponse.equals("NOTSUCCESS")){
                        IndicadoresDeProceso(Finalizado,"ProgService");
                        Toast.makeText(getApplicationContext(), "Fallo la Solicitud. Intente nuevamente " +response, Toast.LENGTH_SHORT).show();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Toast.makeText(getApplicationContext(),"Error ProgEscSecond - EjecProgram BadConexión: " + error.toString(),Toast.LENGTH_LONG).show();
                    IndicadoresDeProceso(Finalizado, "ProgService");
                }
            }){

                // Mapa de toda la Información con la que se solicitará el servicio. <-- IMPORTANTE
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String>parametros = new HashMap<String, String>();
                    //parametros.put("ESTADO_SERVICIO", "PROGRAMADO");
                    parametros.put("TIPOESCALERA",getIntent().getStringExtra("tipo"));
                    parametros.put("PASOS",getIntent().getStringExtra("pasos"));
                    parametros.put("NUM_ESCALERA", NEscalera);
                    parametros.put("FECHAINIT",getIntent().getStringExtra("fechaInit"));
                    parametros.put("FECHAEND",getIntent().getStringExtra("fechaEnd"));
                    parametros.put("PARCIALDIAS",getIntent().getStringExtra("totalDias"));

                    parametros.put("NOMBREPROGRAMA",NombreProg);
                    parametros.put("TEL_PROGRAMA",TelProg);
                    parametros.put("CORREOPROGRAMA",EmailProg);
                    parametros.put("DEPARTAMENTOPROGRAMA",AreaProg);

                    parametros.put("NOMBRERECIBE",NombreRecibe.getText().toString());
                    parametros.put("TEL_RECIBE",TelRecibe.getText().toString());
                    parametros.put("CORREORECIBE",EmailRecibe.getText().toString());
                    parametros.put("DEPARTAMENTORECIBE",AreaRecive.getText().toString());

                    parametros.put("OTM",OTM.getText().toString());
                    parametros.put("CLIENTE",ClienteName.getText().toString());
                    parametros.put("NIT",Nit.getText().toString());
                    parametros.put("ADDRESS",ClienteAddress.getText().toString());

                    parametros.put("HORA",HoraEntrega.getText().toString());
                    parametros.put("OBSERVACIONES",Observaciones.getText().toString());

                    return parametros;
                }
            };
            requestQueueToProg= Volley.newRequestQueue(this);
            requestQueueToProg.add(stringRequest);


    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putBoolean("ProgServiceSuccess", ProgServiceSuccess);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        LoadPreference();
        ProgServiceSuccess = savedInstanceState.getBoolean("ProgServiceSuccess");
    }

    //Cargamos Los valores almacenados en las preferencias
    private void LoadPreference() {

        SharedPreferences sharedPreferences = getSharedPreferences("UserLoginPreferences", Context.MODE_PRIVATE);
        NombreProg = sharedPreferences.getString("NOMBRE_USUARIO","NOT_INFO");
        TelProg = sharedPreferences.getString("CELULAR1","NOT_INFO");
        EmailProg = sharedPreferences.getString("CORREO","NOT_INFO");
        AreaProg = sharedPreferences.getString("AREA","NOT_INFO");
    }

    private boolean DataValidation(){
        boolean DataIsCorrect = false;

        if (!NombreProg.equals("NOT_INFO") && !TelProg.equals("NOT_INFO") && !EmailProg.equals("NOT_INFO") && !AreaProg.equals("NOT_INFO")
                && !NombreRecibe.getText().toString().isEmpty() && !TelRecibe.getText().toString().isEmpty() && !EmailRecibe.getText().toString().isEmpty()
                && !OTM.getText().toString().isEmpty() && !ClienteName.getText().toString().isEmpty() && !Nit.getText().toString().isEmpty() && !ClienteAddress.getText().toString().isEmpty() && !HoraEntrega.getText().toString().isEmpty()
                && !Observaciones.getText().toString().isEmpty()) {

            DataIsCorrect = true;

        } else {
            DataIsCorrect = false;
            // Se muestran los mensajes de error en caso de no haber diligenciado algún campo
            if (NombreProg.equals("NOT_INFO") || TelProg.equals("NOT_INFO") || EmailProg.equals("NOT_INFO") || AreaProg.equals("NOT_INFO"))
                Toast.makeText(getApplicationContext(),"Su información es incompleta, Ingrese nuevamente",Toast.LENGTH_LONG).show();
            if (NombreRecibe.getText().toString().trim().equalsIgnoreCase(""))
                NombreRecibe.setError("Nombre de quien recibirá la escalera");
            if (TelRecibe.getText().toString().trim().equalsIgnoreCase(""))
                TelRecibe.setError("Teléfono de quien recibirá la escalera");
            if (EmailRecibe.getText().toString().trim().equalsIgnoreCase(""))
                EmailRecibe.setError("Email de quien recibirá la escalera");
            if(OTM.getText().toString().trim().equalsIgnoreCase(""))
                OTM.setError("Ingrese la OTM/OTP/INS del servicio");
            if (ClienteName.getText().toString().trim().equalsIgnoreCase(""))
                ClienteName.setError("Nombre del Cliente, proyecto o unidad");
            if (Nit.getText().toString().trim().equalsIgnoreCase(""))
                Nit.setError("Número de identificacion del Cliente");
            if (ClienteAddress.getText().toString().trim().equalsIgnoreCase(""))
                ClienteAddress.setError("Dirección de entrega");
            if (HoraEntrega.getText().toString().trim().equalsIgnoreCase(""))
                HoraEntrega.setError("Hora en que se entregará la escalera ne el púnto");
            if (Observaciones.getText().toString().trim().equalsIgnoreCase(""))
                Observaciones.setError("Si no tienes, escribe 'ninguna'");

            Toast.makeText(getApplicationContext(), "Asegurese de haber ingresado toda la información para continuar", Toast.LENGTH_LONG).show();
        }

        return DataIsCorrect;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.HoraEntrega:

                Calendar cal = Calendar.getInstance();
                hora = cal.get(Calendar.HOUR_OF_DAY);
                minuto = cal.get(Calendar.MINUTE);

                final String[] minutos = new String[1];
                final String[] horaDia = new String[1];
                TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        if (minute < 10) minutos[0] = ("0" + minute);
                        else minutos[0] = "" + minute;

                        if (hourOfDay < 10) horaDia[0] = ("0" + hourOfDay);
                        else horaDia[0] = "" + hourOfDay;

                        HoraEntrega.setText(horaDia[0] + ":" + minutos[0] );
                    }
                },hora,minuto,true);
                timePickerDialog.show();
                break;
        }

    }
}
