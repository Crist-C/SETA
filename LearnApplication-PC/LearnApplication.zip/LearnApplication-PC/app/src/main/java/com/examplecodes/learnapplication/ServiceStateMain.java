package com.examplecodes.learnapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ServiceStateMain extends AppCompatActivity {

    Button BotConsultarOTM, BotServIncorrecto, BotServCorrecto;
    TextView ViewProgramo, ViewCliente, ViewClienteAddress, ViewRecibe, ViewEscalera, ViewFechaDesde, ViewFechaHasta;
    EditText OTMtoConsult;
    private Intent IntToServiceState2;
    RequestQueue requestQueue;
    String OTMServiceState = "";
    Boolean ConsultaFinalizada = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_state_main);

        ArrayAdapter<CharSequence> Nombres = ArrayAdapter.createFromResource(this,R.array.NamesList,android.R.layout.simple_dropdown_item_1line);


        BotConsultarOTM = (Button) findViewById(R.id.ButtConsultarOTM);
        BotServIncorrecto = (Button) findViewById(R.id.ButtonServIncorrecto);
        BotServCorrecto = (Button) findViewById(R.id.ButtonServCorrecto);
        OTMtoConsult = (EditText) findViewById(R.id.OTMtoConsult);
        ViewProgramo = (TextView) findViewById(R.id.ViewProgramo);
        ViewCliente = (TextView) findViewById(R.id.ViewCliente);
        ViewClienteAddress = (TextView) findViewById(R.id.ViewClienteAddress);
        ViewRecibe = (TextView) findViewById(R.id.ViewRecibe);
        ViewEscalera = (TextView) findViewById(R.id.ViewEscalera);
        ViewFechaDesde = (TextView) findViewById(R.id.ViewFechaDesde);
        ViewFechaHasta = (TextView) findViewById(R.id.ViewFechaHasta);
        ConsultaFinalizada = false;


    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putString("ViewProgramo",ViewProgramo.getText().toString());
        outState.putString("ViewCliente", ViewCliente.getText().toString());
        outState.putString("ViewClienteAddress", ViewClienteAddress.getText().toString());
        outState.putString("ViewRecibe",ViewRecibe.getText().toString());
        outState.putString("ViewEscalera",ViewEscalera.getText().toString());
        outState.putString("ViewFechaDesde",ViewFechaDesde.getText().toString());
        outState.putString("ViewFechaHasta",ViewFechaHasta.getText().toString());
        //outState.putString("OTMServiceState", OTMServiceState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        ViewProgramo.setText(savedInstanceState.getString("ViewProgramo"));
        ViewCliente.setText(savedInstanceState.getString("ViewCliente"));
        ViewClienteAddress.setText(savedInstanceState.getString("ViewClienteAddress"));
        ViewRecibe.setText(savedInstanceState.getString("ViewRecibe"));
        ViewEscalera.setText(savedInstanceState.getString("ViewEscalera"));
        ViewFechaDesde.setText(savedInstanceState.getString("ViewFechaDesde"));
        ViewFechaHasta.setText(savedInstanceState.getString("ViewFechaHasta"));
        //OTMServiceState = savedInstanceState.getString("OTMServiceState");
        ConsultaFinalizada = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntToServiceState2 = new Intent(getApplicationContext(), ServiceStateSecond.class);

        BotConsultarOTM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OTMtoConsult.setEnabled(false);
                ConsultarServicio("http://onkaix-com.preview-domain.com/DBConsulta.php?OTService="+OTMtoConsult.getText().toString()+
                        "&&From=SS");
            }
        });

        BotServCorrecto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ConsultaFinalizada == true) {
                    IntToServiceState2.putExtra("EstadoActual", OTMServiceState);
                    IntToServiceState2.putExtra("OTM", OTMtoConsult.getText().toString());
                    ConsultaFinalizada = false;
                    startActivity(IntToServiceState2);
                }
                else Toast.makeText(getApplicationContext(),"Primero consulte un Servicio", Toast.LENGTH_LONG).show();
            }
        });

        BotServIncorrecto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConsultaFinalizada = false;
                OTMtoConsult.setEnabled(true);
                OTMtoConsult.setText("");
                ViewProgramo.setText("");
                ViewCliente.setText("");
                ViewEscalera.setText("");
                ViewFechaDesde.setText("");
                ViewFechaHasta.setText("");
                ViewClienteAddress.setText("");
                ViewRecibe.setText("");
                Toast.makeText(getApplicationContext(), "Ingresa la OTM nuevamente", Toast.LENGTH_LONG ).show();

            }
        });

    }



    private void ConsultarServicio(String URL)
    {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                JSONObject jsonObject = null;

                    for (int i = 0; i < response.length(); i++) {
                        try {
                            jsonObject = response.getJSONObject(i);
                            //El objeto JSon devuelve un valor en la CLave "OTM" = "NoExist", solo si no existe ningún servicio
                            if (!jsonObject.isNull("OTM")) {
                                Toast.makeText(getApplicationContext(),"Este servicio NO EXISTE",Toast.LENGTH_LONG).show();
                                ConsultaFinalizada = false;
                                OTMtoConsult.setEnabled(true);
                                break;
                            }else { // Si el servicio si existe nos retorna todos los valores
                                ViewEscalera.setText(jsonObject.getString("TIPOESCALERA") + " " + jsonObject.getString("PASOS") + " pasos");
                                ViewFechaDesde.setText(jsonObject.getString("FECHAINIT"));
                                ViewFechaHasta.setText(jsonObject.getString("FECHAEND"));
                                ViewProgramo.setText(jsonObject.getString("NOMBREPROGRAMA"));
                                ViewRecibe.setText(jsonObject.getString("NOMBRERECIBE"));
                                ViewCliente.setText(jsonObject.getString("CLIENTE"));
                                ViewClienteAddress.setText(jsonObject.getString("ADDRESS"));
                                OTMServiceState = jsonObject.getString("ESTADO_SERVICIO");
                                ConsultaFinalizada = true;

                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            ConsultaFinalizada = false;
                        }
                    }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Toast.makeText(getApplicationContext(), "Error de Conexión:" + error.toString(),Toast.LENGTH_LONG).show();
                ConsultaFinalizada = false;
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);


    }


}


