package com.examplecodes.learnapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class ListOfService extends AppCompatActivity {

    String[] OTs;
    String[] Clientes;
    String[] TipoEscalera;
    String[] Address;
    String[] Date;
    String[] EstadoServicio;
    String[] TipoRuta;

    ListView ListServices;
    Button NuevaConsulta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_service);

        OTs= getIntent().getStringArrayExtra("OTs");
        Clientes = getIntent().getStringArrayExtra("CLIENTES");
        TipoEscalera = getIntent().getStringArrayExtra("TIPOESCALERA");
        Address = getIntent().getStringArrayExtra("ADDRESS");
        Date = getIntent().getStringArrayExtra("DATE");
        EstadoServicio = getIntent().getStringArrayExtra("ESTADO_SERVICIO");
        TipoRuta = getIntent().getStringArrayExtra("TIPO_RUTA");

        ListServices = (ListView) findViewById(R.id.listOfServices);
        ListServices.setAdapter(new ListServiceAdapter(this, OTs, Clientes, TipoEscalera, Address, Date, EstadoServicio, TipoRuta));






    }



}
