package com.examplecodes.learnapplication.Funciones;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.examplecodes.learnapplication.DataModel;
import com.examplecodes.learnapplication.ProgramFragments.InterfazActivityFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DataBase {


    Context context;
    Activity ActivityContenedora;
    DataModel dataModel;
    private RequestQueue requestQueue;
    private String EscaleraDisponible, ReferenciaAndDisponible, SeccionesDisponibles, HSEDisponible, EPCC;




    boolean LeadderIsAvaliable, AndamioIsAvaliable, HSEIsAvaliable, M1Avaliable, M2Avaliable, M3Avaliable, M4Avaliable;
    boolean [] EPCCIsAvaliable = {false,false,false,false};
    boolean returnEPCCAvaliable = true;
    String [] EPCCDisponible = {"","","",""};

    private String URLDispEscalera = "http://onkaix-com.preview-domain.com/DBConsDispEscalera.php?",
                    URLDispAndamio = "http://onkaix-com.preview-domain.com/DBConsDispAndamio.php?",
                    URLDispHSE = "http://onkaix-com.preview-domain.com/DBConsDispHSE.php?",
                    URLDispEqAltura = "http://onkaix-com.preview-domain.com/DBConsDispEPCC.php?";

    public DataBase(Context context, Activity ActivityContenedora, DataModel dataModel) {
        this.context = context;
        this.ActivityContenedora = ActivityContenedora;
        this.dataModel = dataModel;
    }


    //TipoEscalera=" + TipoEsc + "&Pasos=" + TextNPasosInd.getText().toString() + "&Numero=0&FechaInit=" + FechaInitSolicitud.getText().toString() + "&FechaEnd=" + FechaEndSolicitud.getText().toString();

    public boolean ConsultarEscaleraDisponible(final String TipoEscalera, final String PasosEscalera, String FI, String FE, String Referencia)
    {

        URLDispEscalera += ("TipoEscalera="+TipoEscalera+"&Pasos="+PasosEscalera+"&Referencia="+Referencia+"&FechaInit='"+FI+"'&FechaEnd='"+FE+"'");
        //Toast.makeText(context, URLDispEscalera, Toast.LENGTH_LONG).show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URLDispEscalera, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {


                JSONObject jsonObject = null;

                try {

                    jsonObject = response.getJSONObject(0); // Escogemos el primer Objeto JSON
                    EscaleraDisponible = (jsonObject.getString("NumeroEscalera"));
                    // Escogemos el valor con la CLAVE "NumeroEscalera"

                    if (EscaleraDisponible.equals("NoExist")){
                        SetResults("Escalera", false);
                        Toast.makeText(context, "Esta escalera NO EXISTE en el Inventario", Toast.LENGTH_SHORT).show();
                    }else if(EscaleraDisponible.equals("0")){
                        SetResults("Escalera", false);
                        Toast.makeText(context, "Esta escalera NO se encuentra disponible. Intenta en otras fechas", Toast.LENGTH_LONG).show();
                    }else if (!EscaleraDisponible.equals("0")){
                        SetResults("Escalera", true);
                        Toast.makeText(context, "Escalera disponible: " + TipoEscalera + " " + PasosEscalera + " Pasos No."+ EscaleraDisponible, Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    SetResults("Escalera", false);
                    Toast.makeText(context, "Jarray Error 1: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                SetResults("Escalera", false);
                Toast.makeText(context, "Jarray Error 1:" + error.getMessage(), Toast.LENGTH_LONG ).show();
            }
        });
        requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(jsonArrayRequest);

        return LeadderIsAvaliable;
    }

    public void SetResults(String EquipoSolicitado, boolean Exitoso){

        dataModel.Solicitud = Exitoso;

        switch (EquipoSolicitado){
            case "Escalera": LeadderIsAvaliable = Exitoso;
                ((InterfazActivityFragment)ActivityContenedora).LadderData(dataModel);
                break;
            case "Andamio": AndamioIsAvaliable = Exitoso;
                ((InterfazActivityFragment)ActivityContenedora).AndamioData(dataModel);
                break;
            case "HSE": HSEIsAvaliable = Exitoso;
                ((InterfazActivityFragment)ActivityContenedora).AlturaData(dataModel);
                break;
            case "EPCC": returnEPCCAvaliable = Exitoso; ((InterfazActivityFragment)ActivityContenedora).AlturaData(dataModel);
                break;
        }


    }

    public boolean ConsultarAndamioDisponible(final String TipoAndamio, final String Secciones, String FI, String FE, String Referencia)
    {

        URLDispAndamio += ("TipoAndamio="+TipoAndamio+"&Secciones="+Secciones+"&Referencia="+Referencia+"&FechaInit='"+FI+"'&FechaEnd='"+FE+"'");
        //Toast.makeText(context, URLDispEscalera, Toast.LENGTH_LONG).show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URLDispAndamio, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {


                JSONObject jsonObject = null;

                try {

                    jsonObject = response.getJSONObject(0); // Escogemos el primer Objeto JSON
                    SeccionesDisponibles = (jsonObject.getString("ReferenciaAndamio"));
                    ReferenciaAndDisponible = SeccionesDisponibles;
                    // Escogemos el valor con la CLAVE "NumeroEscalera"

                    if (SeccionesDisponibles.equals("NoExist")){
                        SetResults("Andamio",false);
                        Toast.makeText(context, "El andamio NO está disponible en el Inventario", Toast.LENGTH_SHORT).show();
                    }else if((TipoAndamio.equals("Certificado") && Integer.parseInt(SeccionesDisponibles) < Integer.parseInt(Secciones)) ||
                            (TipoAndamio.equals("Unipersonal") && ReferenciaAndDisponible.equals("0"))){
                        if (TipoAndamio.equals("Certificado")){
                            Toast.makeText(context, "La cantidad de secciones que requiere NO se encuentran disponibles.", Toast.LENGTH_SHORT).show();
                            Toast.makeText(context, "La cantidad de secciones disponibles en las fechas son "+ SeccionesDisponibles, Toast.LENGTH_LONG).show();
                        }else Toast.makeText(context, "El andamio" +TipoAndamio+" NO se encuentran disponible. Intenta en otras fechas", Toast.LENGTH_SHORT).show();

                        SetResults("Andamio",false);

                    }else if (Integer.parseInt(SeccionesDisponibles) >= Integer.parseInt(Secciones) || !ReferenciaAndDisponible.equals("0")){
                        SetResults("Andamio",true);
                        if (TipoAndamio.equals("Certificado")){
                            Toast.makeText(context, "Se anexó a la solicitud: " + Secciones + " Secciones de Andamio "+ TipoAndamio, Toast.LENGTH_SHORT).show();
                        }else Toast.makeText(context, "Se anexó a la solicitud: Andamio "+ TipoAndamio + " No "+ReferenciaAndDisponible, Toast.LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {
                    SetResults("Andamio",false);
                    Toast.makeText(context, "Jarray Error 1: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                SetResults("Andamio",false);
                Toast.makeText(context, "Jarray Error 1:" + error.getMessage(), Toast.LENGTH_LONG ).show();
            }
        });
        requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(jsonArrayRequest);

        return AndamioIsAvaliable;
    }

    public boolean PersonalHSE(final String NombreHSE, final String Horario, String FI, String FE)
    {

        URLDispHSE += ("Horario="+Horario+"&Nombre="+NombreHSE+"&FechaInit='"+FI+"'&FechaEnd='"+FE+"'");
        //Toast.makeText(context, URLDispHSE, Toast.LENGTH_LONG).show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URLDispHSE, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {


                JSONObject jsonObject = null;

                try {

                    jsonObject = response.getJSONObject(0); // Escogemos el primer Objeto JSON
                    HSEDisponible = (jsonObject.getString("HSE"));

                    // Escogemos el valor con la CLAVE "NumeroEscalera"

                    if (HSEDisponible.equals("DESHABILITADO")){
                        Toast.makeText(context, "El personal HSE NO habilitado", Toast.LENGTH_SHORT).show();
                        SetResults("HSE", false);

                    }else if(HSEDisponible.equals("NO_DISPONIBLE")){
                        Toast.makeText(context, "El personal HSE NO se encuentra disponible.", Toast.LENGTH_SHORT).show();
                        SetResults("HSE", false);
                    }else {
                        SetResults("HSE", true);
                        Toast.makeText(context, "Se agendó al Coordinador: " + HSEDisponible, Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    Toast.makeText(context, "Jarray HSE 1: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    SetResults("HSE", false);
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Jarray HSE 2:" + error.getMessage(), Toast.LENGTH_LONG ).show();
                SetResults("HSE", false);
            }
        });
        requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(jsonArrayRequest);

        return HSEIsAvaliable;
    }

    public boolean EquiposAltura(final int NMaletas, final int[] Bags, String FI, String FE)
    {

        URLDispEqAltura += ("NMaletas="+NMaletas+"&M1="+Bags[0]+"&M2="+Bags[1]+"&M3="+Bags[2]+"&M4="+Bags[3]+"&FechaInit='"+FI+"'&FechaEnd='"+FE+"'");
        //Toast.makeText(context, URLDispEqAltura, Toast.LENGTH_LONG).show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URLDispEqAltura, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {


                JSONObject jsonObject = null;
                String Desabilitados = null, Disponibles = null,  NoDisponible = null;

                try {

                    jsonObject = response.getJSONObject(0); // Escogemos el primer Objeto JSON
                    for (int i = 0; i < NMaletas; i++){
                        // Escogemos el valor con la CLAVE "EPCCx"
                        int e = i+1;
                        EPCCDisponible[i] = (jsonObject.getString("EPCC"+(i+1) ));
                        //Toast.makeText(context, "EPCC"+ (i+1) + " "+EPCCDisponible[i], Toast.LENGTH_SHORT).show();


                        if (EPCCDisponible[i].equals("DESHAB")){
                            if (Desabilitados == null) Desabilitados = (""+Bags[i]); else Desabilitados += (" ,"+Bags[i]);
                            EPCCIsAvaliable[i]=false;
                            returnEPCCAvaliable &= EPCCIsAvaliable[i];
                        } else if (EPCCDisponible[i].equals("DIS")){
                            if (Disponibles == null) Disponibles = (""+Bags[i]); else Disponibles += (" ,"+Bags[i]);
                            EPCCIsAvaliable[i]=true;
                            returnEPCCAvaliable &= EPCCIsAvaliable[i];
                        } else {
                            if (NoDisponible == null) NoDisponible = (""+Bags[i]); else NoDisponible += (" ,"+Bags[i]);
                            EPCCIsAvaliable[i]=false;
                            returnEPCCAvaliable &= EPCCIsAvaliable[i];
                        }

                    }
                    SetResults("EPCC",returnEPCCAvaliable);
                    if (Disponibles != null && Desabilitados == null && NoDisponible == null){
                        Toast.makeText(context, "Todos los EPCC se añadieron con éxito:", Toast.LENGTH_SHORT).show();
                    } else if (Disponibles != null && (Desabilitados != null || NoDisponible != null)){
                        Toast.makeText(context, "Los EPCC: "+ NoDisponible +","+ Desabilitados +" No se encuentran disponibles", Toast.LENGTH_SHORT).show();
                        Toast.makeText(context, "Los EPCC NO se añadieron de manera éxitosa, intente con otros.", Toast.LENGTH_SHORT).show();
                    } else if (Disponibles == null) Toast.makeText(context, "Ningún EPCC se encuentra disponible, intente con otros.", Toast.LENGTH_SHORT).show();


                } catch (JSONException e) {
                    Toast.makeText(context, "Jarray EPCC 1: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    SetResults("EPCC", false);
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Jarray EPCC 2:" + error.getMessage(), Toast.LENGTH_LONG ).show();
                SetResults("EPCC", false);
            }
        });
        requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(jsonArrayRequest);

        return returnEPCCAvaliable;
    }


    public boolean isLeadderIsAvaliable() {
        return LeadderIsAvaliable;
    }

    public boolean isAndamioIsAvaliable() {
        return AndamioIsAvaliable;
    }

    public boolean isHSEIsAvaliable() {
        return HSEIsAvaliable;
    }

    public boolean[] getEPCCIsAvaliable() {
        return EPCCIsAvaliable;
    }


}
