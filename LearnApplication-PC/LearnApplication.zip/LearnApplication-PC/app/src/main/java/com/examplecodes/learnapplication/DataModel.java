package com.examplecodes.learnapplication;

import androidx.lifecycle.ViewModel;

public class DataModel extends ViewModel {
    //Solicitud de escalera
    public String LadderType, LadderSteps, DILadder, DELadder;
    public String NumLadderReference, LadderTotalDays;
    public boolean LadderReference, LadderAvaliable, HSE, Solicitud;

    public String AndamioType, NumAndamReference, Secciones;
    public String DIAndamio, DEAndamio, AndamTotalDays;
    public boolean AndamReference, AndamAvaliable;


    static final int LimiteEQAltura = 4;
    public boolean EQ_Descenso, Cuerda;
    public String HorarioHSE, Señalizacion, AlturaMaxima;
    public String DIEQAltura, DEEQAltura, EPCCTotalDias;
    public int TotalEQAltura = 0;
    public int[] Bags = {0,0,0,0};


}
