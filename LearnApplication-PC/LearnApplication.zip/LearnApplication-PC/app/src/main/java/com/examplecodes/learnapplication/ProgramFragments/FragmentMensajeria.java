package com.examplecodes.learnapplication.ProgramFragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.ToggleButton;

import com.examplecodes.learnapplication.R;


public class FragmentMensajeria extends Fragment {


    ToggleButton ButMoto, ButCarro;
    Spinner ZonaMoto, FuncionMoto, CamionCamioneta, FuncionCarro;
    EditText ObservMoto, ObservCarro;

    ArrayAdapter ArrAdapZonaMoto, ArrAdapFuncionMoto, ArrAdapCamionCamioneta, ArrAdapFuncionCarro;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_mensajeria, container, false);
        ButMoto = (ToggleButton) view.findViewById(R.id.MotoTB);
        ButCarro = (ToggleButton) view.findViewById(R.id.CamionButton);
        ZonaMoto = (Spinner) view.findViewById(R.id.SZonaMoto);
        FuncionMoto = (Spinner) view.findViewById(R.id.SFuncionMoto);
        CamionCamioneta = (Spinner) view.findViewById(R.id.SCamionCamioneta);
        FuncionCarro = (Spinner) view.findViewById(R.id.FuncionCamionSpinner);
        ObservMoto = (EditText) view.findViewById(R.id.ETObservMoto);
        ObservCarro = (EditText) view.findViewById(R.id.ETObservCarro);

        ArrAdapZonaMoto = ArrayAdapter.createFromResource(getContext(),R.array.ZonaMoto,android.R.layout.simple_dropdown_item_1line);
        ArrAdapZonaMoto.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ZonaMoto.setAdapter(ArrAdapZonaMoto);

        ArrAdapFuncionMoto = ArrayAdapter.createFromResource(getContext(),R.array.FuncionesMoto,android.R.layout.simple_dropdown_item_1line);
        ArrAdapFuncionMoto.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        FuncionMoto.setAdapter(ArrAdapFuncionMoto);

        ArrAdapCamionCamioneta = ArrayAdapter.createFromResource(getContext(),R.array.TipoVehiculo,android.R.layout.simple_dropdown_item_1line);
        ArrAdapCamionCamioneta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        CamionCamioneta.setAdapter(ArrAdapCamionCamioneta);

        ArrAdapFuncionCarro = ArrayAdapter.createFromResource(getContext(),R.array.FuncionCarro,android.R.layout.simple_dropdown_item_1line);
        ArrAdapFuncionCarro.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        FuncionCarro.setAdapter(ArrAdapFuncionCarro);

        CamionCamioneta.setEnabled(false);
        FuncionCarro.setEnabled(false);
        ObservCarro.setEnabled(false);


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        ButMoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!ButMoto.isChecked()){
                    ZonaMoto.setEnabled(false);
                    FuncionMoto.setEnabled(false);
                    ObservMoto.setEnabled(false);


                } else if (ButMoto.isChecked()){

                        ZonaMoto.setEnabled(true);
                        FuncionMoto.setEnabled(true);
                        ObservMoto.setEnabled(true);

                        if (ButCarro.isChecked()){
                            ButCarro.setChecked(false);
                            CamionCamioneta.setEnabled(false);
                            FuncionCarro.setEnabled(false);
                            ObservCarro.setEnabled(false);
                        }

                }


            }
        });


        ButCarro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!ButCarro.isChecked()){

                    CamionCamioneta.setEnabled(false);
                    FuncionCarro.setEnabled(false);
                    ObservCarro.setEnabled(false);

                } else if (ButCarro.isChecked()){

                    CamionCamioneta.setEnabled(true);
                    FuncionCarro.setEnabled(true);
                    ObservCarro.setEnabled(true);

                    if (ButMoto.isChecked()){
                        ButMoto.setChecked(false);
                        ZonaMoto.setEnabled(false);
                        FuncionMoto.setEnabled(false);
                        ObservMoto.setEnabled(false);
                    }

                }


            }
        });

    }

    public FragmentMensajeria() {
        // Required empty public constructor
    }

    public static FragmentMensajeria newInstance(String param1, String param2) {
        FragmentMensajeria fragment = new FragmentMensajeria();

        return fragment;
    }


}