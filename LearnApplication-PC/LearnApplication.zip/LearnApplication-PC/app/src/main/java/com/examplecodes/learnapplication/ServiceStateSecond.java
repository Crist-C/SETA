package com.examplecodes.learnapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ServiceStateSecond extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView EstadoActual;
    EditText AccessCode;
    Button ButChangeState;
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    String NextEstate, State, OTM;
    String KeyConductor1 = "1919", KeyConductor2 = "2919", KeyTecnico, KeyProg1 = "1828", KeyProg2 = "2828", KeyMaster = "060995";

    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.service_state_second);

        EstadoActual = (TextView) findViewById(R.id.ViewServiceState);
        AccessCode = (EditText) findViewById(R.id.ViewAccesCode);
        ButChangeState = (Button) findViewById(R.id.ButtChangeState);
        spinner = findViewById(R.id.SpinerState);                             // Se instancia el Spinner ()

        EstadoActual.setText(getIntent().getStringExtra("EstadoActual"));              // Se recibe el estado actual desde la Activity anterior
        State = EstadoActual.getText().toString();
        OTM =  getIntent().getStringExtra("OTM");
        SpinnerAdapter(State);

    }


    @Override
    protected void onResume() {
        super.onResume();

        SpinnerAdapter(State);

        // Cuando se presione el Boton Cambiar estado, se evalua ¿Cual es el seguiente estado de la OTM?
        // Luego se evalua que PERFIL es quien intenta realizar el cambio. si esta autorizado se ejecutará el cambio
        // NEXT STATE               AGENTE PERMITIDO
        //  TRANSITO A SERVICIO - CONDUCTOR, MASTER
        //  EJECUCIÓN           - CONDUCTOR, MASTER
        //  FINALIZADO          - TÉCNICO, PROGRAMADOR
        //  CANCELADO           - TÉCNICO, PROGRAMADOR
        //  RECOGIDO            - CONDUCTOR, MASTER
        //
        ButChangeState.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (AccessCode.getText().toString().isEmpty() || (!AccessCode.getText().toString().equals(KeyConductor1) && !AccessCode.getText().toString().equals(KeyConductor2) && !AccessCode.getText().toString().equals(KeyMaster) &&
                        !AccessCode.getText().toString().equals(KeyProg1) && !AccessCode.getText().toString().equals(KeyProg2) && !AccessCode.getText().toString().equals(KeyTecnico))){
                    Toast.makeText(getApplicationContext(),"No tiene permisos para realizar el cambio", Toast.LENGTH_SHORT).show();}
                else {
                    switch (NextEstate) {

                        case "TRANSITO_SERVICIO":
                        case "EJECUCION":
                        case "RECOGIDO":

                            if (AccessCode.getText().toString().equals(KeyConductor1) || AccessCode.getText().toString().equals(KeyConductor2) || AccessCode.getText().toString().equals(KeyMaster)) {
                                //ejecutar servicio Cambiar estado
                                ChangeServiceState(OTM, NextEstate);
                                Toast.makeText(getApplicationContext(), "Cambio realizado a " + NextEstate, Toast.LENGTH_LONG).show();
                            } else
                                Toast.makeText(getApplicationContext(), "No tiene permisos para realizar el cambio", Toast.LENGTH_SHORT).show();
                            break;

                        case "FINALIZADO":
                        case "CANCELADO":

                            if (AccessCode.getText().toString().equals(KeyProg1) || AccessCode.getText().toString().equals(KeyProg2) || AccessCode.getText().toString().equals(KeyTecnico) || AccessCode.getText().toString().equals(KeyMaster)){
                                //ejecutar servicio Cambiar estado
                                ChangeServiceState(OTM, NextEstate);
                                Toast.makeText(getApplicationContext(), "Cambio autorizado a " + NextEstate, Toast.LENGTH_LONG).show();
                            }else Toast.makeText(getApplicationContext(),"No tiene permisos para realizar el cambio", Toast.LENGTH_SHORT).show();
                            break;

                        default:
                            Toast.makeText(getApplicationContext(), "Estado Desconocido", Toast.LENGTH_SHORT).show();

                            break;
                    }
                }

            }
        });

    }

    private void SpinnerAdapter(String State)
    {
        switch (State){ // Según el estado actual del servicio se despliega una lista

            case "PROGRAMADO":
                adapter = ArrayAdapter.createFromResource(this, R.array.PROGRAMATED_STATES, android.R.layout.simple_spinner_item);
                break;
            case "TRANSITO_SERVICIO":
                adapter = ArrayAdapter.createFromResource(this, R.array.TRANSITO_STATES, android.R.layout.simple_spinner_item);
                break;
            case "EJECUCION":
                adapter = ArrayAdapter.createFromResource(this, R.array.EJECUCION_STATES, android.R.layout.simple_spinner_item);
                break;
            case "FINALIZADO":
                adapter = ArrayAdapter.createFromResource(this, R.array.FINALIZADO_STATES, android.R.layout.simple_spinner_item);
                break;
            case "CANCELADO":
                adapter = ArrayAdapter.createFromResource(this, R.array.CANCELADO_STATES, android.R.layout.simple_spinner_item);
                spinner.setEnabled(false);
                break;
            case "RECOGIDO":
                adapter = ArrayAdapter.createFromResource(this, R.array.RECOGIDO_STATES, android.R.layout.simple_spinner_item);
                spinner.setEnabled(false);
                break;
            default: Toast.makeText(getApplicationContext(),"Estado Desconocida¿o", Toast.LENGTH_LONG).show();
                adapter = ArrayAdapter.createFromResource(this, R.array.CANCELADO_STATES, android.R.layout.simple_spinner_item);
                spinner.setEnabled(false);
                break;
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }

    // Crea un servicio en la Base de Datos
    private void ChangeServiceState(final String OTM, final String NewEstate){

        String URL = "http://onkaix-com.preview-domain.com/DBChangeServiceState.php";
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                try {
                    //Se transforma el String response en un JSONArray
                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject Estado;
                    //Luego se extrae el primer objeto del array
                    Estado = jsonArray.getJSONObject(0);

                    if (!Estado.isNull("ESTADO_SERVICIO")){

                        EstadoActual.setText(Estado.getString("ESTADO_SERVICIO"));
                        SpinnerAdapter(Estado.getString("ESTADO_SERVICIO"));

                    }else Toast.makeText(getApplicationContext(),Estado.getString("ESTADO"),Toast.LENGTH_LONG).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"Error CambEstad: "+e.getMessage(),Toast.LENGTH_LONG).show();
                }
                //Change Service State Success = true;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Error ProgEscSecond - EjecProgram BadConexión: " + error.toString(),Toast.LENGTH_LONG).show();
                //ProgServiceSuccess = false;
            }
        }){

            // Mapa de toda la Información con la que se solicitará el servicio. <-- IMPORTANTE
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String>parametros = new HashMap<String, String>();
                parametros.put("NewEstate", NewEstate);
                parametros.put("OTM",OTM);

                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        NextEstate = parent.getItemAtPosition(position).toString();

        switch (NextEstate) {
            case "Transito a Servicio": NextEstate = "TRANSITO_SERVICIO"; break;
            case "Ejecución":           NextEstate = "EJECUCION"; break;
            case "Recogido":            NextEstate = "RECOGIDO"; break;
            case "Finalizado":          NextEstate = "FINALIZADO"; break;
            case "Cancelado":           NextEstate = "CANCELADO"; break;
            default:
                //Toast.makeText(getApplicationContext(), "Estado Desconocido", Toast.LENGTH_SHORT).show();
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
